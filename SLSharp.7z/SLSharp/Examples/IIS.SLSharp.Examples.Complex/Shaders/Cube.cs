﻿using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace IIS.SLSharp.Examples.Complex.Shaders
{
    public class Cube
    {
        public void Render()
        {
            var vertices = new[]
                               {
                                   new Vector3(-1.0f, -1.0f, -1.0f), 
                                   new Vector3( 1.0f, -1.0f, -1.0f),
                                   new Vector3(-1.0f,  1.0f, -1.0f),
                                   new Vector3( 1.0f,  1.0f, -1.0f),
                                   new Vector3(-1.0f, -1.0f,  1.0f), 
                                   new Vector3( 1.0f, -1.0f,  1.0f),
                                   new Vector3(-1.0f,  1.0f,  1.0f),
                                   new Vector3( 1.0f,  1.0f,  1.0f),
                               };
            var indices = new short[]
                              {
                                  2, 3, 1, 0, // back
                                  4, 6, 2, 0, // left
                                  1, 3, 7, 5, // right
                                  4, 5, 7, 6, // front
                                  0, 1, 5, 4, // bottom
                                  6, 7, 3, 2, // top
                              };

            GL.Begin(BeginMode.Quads);
            foreach (var i in indices)
                GL.Vertex3(vertices[i]);
            GL.End();
        }
    }
}
