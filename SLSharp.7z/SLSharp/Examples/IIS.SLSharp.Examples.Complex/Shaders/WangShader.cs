﻿using IIS.SLSharp.Annotations;
using IIS.SLSharp.Textures;

namespace IIS.SLSharp.Examples.Complex.Shaders
{
    public abstract class WangShader: Shader
    {
        [Uniform] public abstract Sampler2D WangTiles { set; get; }

        [Uniform] public abstract Sampler2D WangMap { set; get; }

        public Texture2D Tiles;
        public Texture2D WangTable;

        [FragmentShader]
        public vec4 WangAt(vec2 tex)
        {
            vec2 address = tex - mod(tex, 1.0f / 256.0f);
            vec2 subPos = fract(tex * 256.0f) / 4.0f;
            vec2 offset = texture2D(WangMap, fract(address)).xw;
            vec2 tc = offset + subPos;
            vec2 tileScaledTex = tex * new vec2(32.0f / 1.0f);
            return textureGrad(WangTiles, tc, dFdx(tileScaledTex), dFdy(tileScaledTex));
        }

        protected WangShader()
        {
            Compile(130);
        }

        public override void Begin()
        {
            base.Begin();
            WangTiles = BindTexture(Tiles);
            WangMap = BindTexture(WangTable);
        }
    }
}


