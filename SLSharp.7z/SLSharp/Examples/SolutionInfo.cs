using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Ignite Interactive Studio")]
[assembly: AssemblyProduct("SL#")]
[assembly: AssemblyCopyright("Copyright � Ignite Interactive Studio")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]
